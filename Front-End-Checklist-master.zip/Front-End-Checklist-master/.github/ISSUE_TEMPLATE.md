<!-- Love front-end-checklist? Please consider supporting our collective:
👉  https://opencollective.com/front-end-checklist/donate -->